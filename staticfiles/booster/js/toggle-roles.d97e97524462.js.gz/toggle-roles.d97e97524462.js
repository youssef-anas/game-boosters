$('#read-roles').on("click", function(){
  $("#roles").slideDown("slow")
})
$('#understand-roles').on("click", function(){
  $("#roles").slideUp("slow")
})